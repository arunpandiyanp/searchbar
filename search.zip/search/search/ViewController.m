//
//  ViewController.m
//  search
//
//  Created by arun pandiyan  on 08/10/16.
//  Copyright © 2016 arun pandiyan . All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    
    allitem=[[NSArray alloc]initWithObjects:@"one",@"two",@"three",@"four",@"five",@"six",nil];
    displayitem=[[NSMutableArray alloc]initWithArray:allitem];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardShown:) name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardHidden:) name:UIKeyboardWillHideNotification object:nil];//keyboard will hide
    
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)keyboardShown:(NSNotification *)note{
    CGRect keyboardFrame;
    [[[note userInfo]objectForKey:UIKeyboardFrameEndUserInfoKey]getValue:&keyboardFrame];//set keyboard frame
    CGRect tableViewFrame=tableview.frame;
    tableViewFrame.size.height-=keyboardFrame.size.height;//height of the keyboard from the table view
    [tableview setFrame:tableViewFrame];//every single time keyboard will display.keyboard that way we can resize the tableview
    
}
-(void)keyboardHidden:(NSNotification *)note{
    [tableview setFrame:self.view.bounds];
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView; {
    return 1;
    //No of sectionin our tableview
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return [displayitem count];
    //no of rows
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(!cell){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }cell.textLabel.text=[displayitem objectAtIndex:indexPath.row];//we just getting item.
    return cell;

//contents of row
}
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText;
{
    if([searchText length]==0){
        [displayitem removeAllObjects];//nothing about textfield,nothing will diplay
        [displayitem addObjectsFromArray:allitem];//it display
        
    }else{
        [displayitem removeAllObjects];
        for (NSString * string in allitem) {
            NSRange r=[string rangeOfString:searchText options:NSCaseInsensitiveSearch];
            if (r.location !=NSNotFound) {
                [displayitem addObject:string];
                //checking string matches the text
                
            }
        }
    }[tableview reloadData];//daybyday data change so,reload data in tableview
    
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)asearchBar;
{
    [searchBar resignFirstResponder];//dismiss keyboard
    
    
}

// called when keyboard search button pressed


// called when text changes (including clear)



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
