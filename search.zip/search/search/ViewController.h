//
//  ViewController.h
//  search
//
//  Created by arun pandiyan  on 08/10/16.
//  Copyright © 2016 arun pandiyan . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate> //basic setup


{
    IBOutlet UITableView *tableview;
    IBOutlet UISearchBar *searchBar;
    NSArray *allitem;
    NSMutableArray *displayitem;
    
    
}


@end

